import React, { useState, useEffect } from 'react';
import './Search.css'; // Importing the CSS file
import '../fonts.css'; // Import the new CSS file with the font-face rule

function Search() {
  const [selectedValue, setSelectedValue] = useState('');

  const handleSelectChange = (event) => {
    setSelectedValue(event.target.value);
  };

  useEffect(() => {
    const btn = document.querySelector('.btn-select');
    const list = document.querySelector('.list-member');

    const handleBtnClick = () => {
      list.classList.toggle('on');
      btn.classList.toggle('click');
    };

    const handleListClick = (event) => {
      if (event.target.nodeName === "BUTTON") {
        btn.innerText = event.target.innerText;
        list.classList.remove('on');
        btn.classList.remove('click');
      }
    };

    btn.addEventListener('click', handleBtnClick);
    list.addEventListener('click', handleListClick);

    return () => {
      btn.removeEventListener('click', handleBtnClick);
      list.removeEventListener('click', handleListClick);
    };
  }, []);

  return (

    <div className="Search">
      <div className="checkbox-table">

        <h1>검색 페이지</h1>

        
        <div className="input-text-group">
          <input className="form-field" type="text" placeholder="인장 강도" />
          <input className="form-field" type="text" placeholder="항복 강도" />
          <input className="form-field" type="text" placeholder="경도" />
          <input className="form-field" type="text" placeholder="연신율" />
        </div>

        <div className="input-select-group">
          <select 
            value={selectedValue} 
            onChange={handleSelectChange} 
            className="property"
          >
            <option value="1">선택값</option>
            <option value="1">1차</option>
            <option value="2">2차</option>
            <option value="3">3차</option>
          </select>
        </div>
        <div className="input-select-group">
          <select className="property">
            <option value="1">설비제품</option>
            <option value="1">1차</option>
            <option value="2">2차</option>
            <option value="3">3차</option>
          </select>
        </div>
        <div className="input-select-group">
          <select className="property">
            <option value="1">선택값</option>
            <option value="1">1차</option>
            <option value="2">2차</option>
            <option value="3">3차</option>
          </select>
        </div>

        <section className="select-section">
          <h2 className="hidden">최애 프로그래밍 언어 선택하기</h2>
          <button className="btn-select">최애 프로그래밍 언어</button>
          <ul className="list-member">
            <li><button className="button">Python</button></li>
            <li><button className="button">Java</button></li>
            <li><button className="button">JavaScript</button></li>
            <li><button className="button">C#</button></li>
            <li><button className="button">C/C++</button></li>
          </ul>
        </section>



        <tbody>
          <tr>
            <th>인장강도</th>
            <td colSpan="4">
              <input type="text" />
            </td>
          </tr>
          <tr>
            <th>항복강도</th>
            <td colSpan="4">
              <input type="text" />
            </td>
          </tr>
          <tr>
            <th>경도</th>
            <td colSpan="4">
              <input type="text" />
            </td>
          </tr>
          <tr>
            <th>연신율</th>
            <td colSpan="4">
              <input type="text" />
            </td>
          </tr>
          <tr>
            <th>설비 제품</th>
            <td colSpan="3">
              <select>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
              </select>
            </td>
          </tr>
          <tr>
            <th>관리</th>
            <td colSpan="3">
              <select>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
              </select>
            </td>
          </tr>
        </tbody>
        <button>입력</button>
      </div>
    </div>
  );
}

export default Search;
